"use client";

import { motion } from "framer-motion";

const features = [
  {
    title: "100% Call Auditing",
    desc: "Never miss a single conversation. AI opportunities, and guide you with a clear roadmap for implementation.",
  },
  {
    title: "GenAI Summaries",
    desc: "Understand every call in seconds — not hours.",
  },
  {
    title: "Emotion & Sentiment Detection",
    desc: "Know how customers really feel.",
  },
  {
    title: "Compliance & Risk Flags",
    desc: "Catch violations before they escalate.",
  },
  {
    title: "Multilingual + Accent Adaptive",
    desc: "Analyze calls in 16+ languages.",
  },
  {
    title: "Role-Based Access & Data Security",
    desc: "Built for global security standards.",
  },
];

const FeaturesCart = () => {
  return (
    <section className="w-full bg-[#0A0A0A] text-white px-4 pt-8">
      <div className="max-w-5xl mx-auto text-center mb-12">
        <h2 className="text-3xl md:text-4xl font-light leading-snug">
          Powerful AI Features That{" "} <br/>
          <span className="font-semibold bg-gradient-to-r from-purple-400 to-pink-500 text-transparent bg-clip-text">
            Make the Difference
          </span>
        </h2>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto px-4">
        {features.map((item, idx) => (
          <motion.div
            key={idx}
            whileHover={{ scale: 1.03 }}
            className="rounded-2xl p-6 min-h-[180px] relative text-left border border-gray-800 transition duration-300 hover:shadow-[0_0_30px_#9333ea]/20"
            style={{
              background:
                "radial-gradient(circle at top left, rgba(91,33,182,0.3), rgba(20,20,20,0.9))",
            }}
          >
            <h3 className="text-white font-semibold text-[16px] mb-2">
              {item.title}
            </h3>
            <p className="text-gray-400 text-sm">{item.desc}</p>
          </motion.div>
        ))}
      </div>
    </section>
  );
};

export default FeaturesCart;
