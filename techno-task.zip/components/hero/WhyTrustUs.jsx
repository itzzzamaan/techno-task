import React from "react";

const trustData = [
  {
    title: "Proven Technical Expertise",
    value: "15+",
    subtitle: "Years of AI-Driven Design",
    description:
      "Our team brings deep experience in machine learning, data engineering, and full-stack development.",
  },
  {
    title: "Highly Customizable Solutions",
    value: "200+",
    subtitle: "Projects Successfully Delivered",
    description:
      "We don't believe in one size fits all. Every solution is tailored to your business needs and workflows.",
  },
  {
    title: "Focus On Real Results",
    value: "95%",
    subtitle: "Client Satisfaction Rate",
    description:
      "We build AI that's safe, transparent, and responsible designed with security & compliance from day one.",
  },
];

export default function WhyTrustUs() {
  return (
    <section className="bg-[#0A0A0A] text-white px-4 pb-6">
      <div className="max-w-6xl mx-auto text-center mb-12">
        <h2 className="text-3xl md:text-4xl font-light">
          Why leading brands trust us to <br />
          deliver smart{" "}
          <span className="font-semibold bg-gradient-to-r from-purple-400 to-pink-500 text-transparent bg-clip-text">
            AI solutions
          </span>
        </h2>
      </div>

      {/* Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6 max-w-6xl mx-auto">
        {trustData.map((item, idx) => (
          <div
            key={idx}
            className="rounded-2xl p-6 bg-gradient-to-br from-[#0c0c2d] to-[#1b012a] hover:scale-105 transform transition-all duration-300"
          >
            <h4 className="text-white font-semibold text-sm mb-2">
              {item.title}
            </h4>
            <div className="text-purple-400 text-3xl font-extrabold mb-1">
              {item.value}
            </div>
            <div className="text-gray-300 text-sm mb-4">{item.subtitle}</div>
            <div className="bg-black/40 p-4 rounded-xl text-sm text-gray-400 leading-relaxed">
              {item.description}
            </div>
          </div>
        ))}
      </div>

      {/* Footer Note */}
      <div className="text-center mt-10 text-sm text-gray-300">
        <span className="bg-purple-600 text-white px-2 py-1 rounded-full text-xs mr-2">
          Free
        </span>
        Let’s make something great work together.{" "}
        <span className="text-purple-400 font-semibold cursor-pointer hover:underline">
          Get Free Quote
        </span>
      </div>
    </section>
  );
}
