"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  SearchCheck,
  BarChart3,
  BrainCog,
  LifeBuoy
} from "lucide-react";


const steps = [
  {
    id: 1,
    title: "Discovery & Strategy",
    step: "STEP 01",
    icon: SearchCheck,
    image: "step1.png",
  },
  {
    id: 2,
    title: "Accurate Dashboard",
    step: "STEP 02",
    icon: BarChart3,
    image: "step2.png",
  },
  {
    id: 3,
    title: "Custom AI Development",
    step: "STEP 03",
    icon: BrainCog,
    image: "step3.png",
  },
  // {
  //   id: 4,
  //   title: "Optimization & Support",
  //   step: "STEP 04",
  //   icon: LifeBuoy,
  //   image: "step3.png",
  // },
];


export default function SolutionCarts() {
  const [activeStep, setActiveStep] = useState(steps[0]);

  return (
    <section className="bg-[#0A0A0A] text-white pb-4 px-4 md:px-10">
      <div className="max-w-6xl mx-auto grid md:grid-cols-2 gap-12 items-center">
        <div className="space-y-6">
          <h2 className="text-3xl md:text-4xl font-light mb-4">
            Our process for smarter <br />
            <span className="font-semibold bg-gradient-to-r from-purple-400 to-pink-500 text-transparent bg-clip-text">
              AI solutions
            </span>
          </h2>

          {steps.map((step) => (
            <motion.div
              key={step.id}
              whileHover={{ scale: 1.03 }}
              onClick={() => setActiveStep(step)}
              className={`relative transition-all duration-300 rounded-2xl p-5 border cursor-pointer overflow-hidden group
                ${
                  activeStep.id === step.id
                    ? "border-purple-600"
                    : "border-zinc-700"
                }`}
            >
              <div className="absolute top-0 left-0 w-[150px] h-[150px]  z-0" />
              <div className="relative z-10 flex items-start gap-4">
                <div className="bg-gradient-to-br from-purple-500 to-pink-500 w-10 h-7 rounded-full flex items-center justify-center text-white">
                 <step.icon className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-sm text-gray-400 font-semibold mb-1">
                    {step.step}
                  </h4>
                  <h3 className="text-lg font-bold text-white mb-1">
                    {step.title}
                  </h3>
                  <p className="text-gray-400 text-sm">
                    We dive deep into your goals and challenges to uncover
                    high-impact AI opportunities and craft a clear.
                  </p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        <div className="relative w-full flex flex-col h-[500px] md:h-[700px]">
          {steps.map((step, idx) => {
            const isActive = step.id === activeStep.id;
            console.log(idx);
            return (
              <motion.img
                key={step.id}
                src={step.image}
                alt={step.title}
                className={`absolute -my-12 inset-0 w-full h-full object-contain rounded-xl transition-all duration-500
          ${
            isActive
              ? "z-30 opacity-100 scale-100"
              : "z-10 opacity-30 scale-[0.96]"
          }`}
                initial={{ opacity: 0 }}
                animate={{ opacity: isActive ? 1 : 0.3 }}
                transition={{ duration: 0.5, delay: isActive ? 0.1 : 0 }}
              />
            );
          })}
        </div>
      </div>
    </section>
  );
}
