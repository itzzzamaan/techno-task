import React from "react";
import Orb from "../org";

const Hero = () => {
  return (
    <div className="relative">
      <div className="w-full h-[600px] relative flex items-center justify-center overflow-hidden">
        <Orb
          hoverIntensity={0.5}
          rotateOnHover={true}
          hue={0}
          forceHoverState={false}
        />

        <div className="absolute z-20 text-center max-w-4xl px-4">
          <h1 className="text-4xl md:text-5xl font-semibold text-white leading-tight">
            Audit 100% of Calls Without <br className="hidden md:block" />
            Hiring 100 QA Agents
          </h1>

          <p className="text-gray-300 text-sm md:text-base mt-4 font-medium max-w-2xl mx-auto">
            AI-Powered Speech Analytics that Audits 100% of Calls, Detects
            Sentiment, Flags Risks, and Boosts Agent Performance — in Real-Time.
          </p>

          <div className="mt-8 flex flex-col sm:flex-row justify-center items-center gap-4">
            <button className="bg-black cursor-pointer text-white border border-white px-6 py-3 rounded-full font-medium hover:bg-white hover:text-black transition-all duration-300">
              Get Started Today
            </button>
            <button className="bg-gradient-to-r cursor-pointer from-purple-500 to-blue-500 text-white px-6 py-3 rounded-full font-medium hover:opacity-90 transition-all duration-300">
              View Demo
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Hero;
