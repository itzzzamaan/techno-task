import Container from "@/components/container";
import BookDemo from "@/components/hero/BookDemo";
import Customers from "@/components/hero/Customers";
import Faq from "@/components/hero/Faq";
import FeaturesCart from "@/components/hero/FeaturesCart";
import Footer from "@/components/hero/Footer";
import Hero from "@/components/hero/hero";
import Navbar from "@/components/hero/Navbar";
import SolutionCarts from "@/components/hero/SolutionCarts";
import StatsCart from "@/components/hero/StatsCart";
import WhatCustomerSays from "@/components/hero/WhatCustomerSays";
import WhyTrustUs from "@/components/hero/WhyTrustUs";
import Orb from "@/components/org";

export default function Home() {
  return (
   <>
    <Container className={" justify-between"}>
      <Navbar/>
<Hero />
<Customers/>
<StatsCart/>
<FeaturesCart/>
<SolutionCarts/>
<WhyTrustUs/>
<WhatCustomerSays/>
<BookDemo/>
<Faq/>

    </Container>
    <Footer/>
   </>
  );
}
